<h1 align="center">
  Tic-Tac-Toe Web
</h1>
<p align="center">Para passar o tempo :)
</p> 

Feito em: **HTML - CSS - JAVASCRIPT**

### Instruções para jogar

- Abra o arquivo jogodavelha.html (o jogo será aberto em seu navegador)
- E chame alguém para jogar :-)



